DOGSMP ROD SHOP COMPLETE — Minecraft 1.21.11

RESOURCE PACK
- 21 fishing-rod models: Custom Model Data 1001–1021.
- Rod model files are preserved from the supplied DOGSMP 21-rod pack.
- Rod Shop GUI font/glyph assets are included.
- The pack uses the 1.21.11 item-model system.

SERVER SCRIPT
- Use DOGSMP_RodShop_COMPLETE.sk together with the existing rod.sk.
- The shop uses giveRod(player, id), so the purchased rod is the same rod system used by the fishing system.
- /shoprod opens the shop.
- /restock performs a full random restock.
- /shoprod restock <id> forces stock for one rod.
- /shoprod setstock <id> <amount> sets stock.
- /shoprod <hours> <minutes> <seconds> sets the countdown.
- Automatic restock is every 2 hours.

IMPORTANT
- The resource pack supplies the 3D rod models and GUI visual assets.
- Vanilla/Skript chest inventories cannot capture a real Java mouse-wheel event. This script therefore uses ▲/▼ buttons, which work for Java and Bedrock/Geyser.
- A true mouse-wheel scrolling GUI requires a GUI plugin/client-side GUI system that exposes wheel scrolling.
- The included GUI texture is not forced over every chest, so normal server chests are not globally ruined.
