DOGSMP PREMIUM FISHING RODS

21 actual Java Block/Item + Blockbench .bbmodel projects.
Custom Model Data: 1001-1021.
Place pack.mcmeta and assets/ at resource pack root.
The pack is designed for Minecraft Java 1.21.4+ item-model definitions.
